package com.example.ckddn.capstoneproject2018_2;


public interface ServerInfo {
    /*  setting server ip address   */
    public static final String ipAddress = "192.168.219.104:5555";   //  Google Cloud Platform 외부 ip
//    public static final String ipAddress = "192.168.0.29:5555";
}
