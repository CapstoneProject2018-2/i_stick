package com.example.ckddn.capstoneproject2018_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

// 내 정보 수정하기 기능 관련 class
//implemented by 양인수
//networking code by 손창우

public class EditParentInfo extends AppCompatActivity {

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_parent_info);
    }

}
