package com.example.ckddn.capstoneproject2018_2;


public interface ServerInfo {
    /*  setting server ip address   */
    public static final String ipAddress = "35.221.79.213:5555";
}
