package com.example.ckddn.capstoneproject2018_2;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

//보호자 모드에서 연락처 목록 데이터 관리하는 Adapter Class
//Filterable 인터페이스는 검색 기능을 위해 추가했음
//implemented by Insu Yang
public class ContactsAdapter  extends BaseAdapter implements Filterable{

    private ArrayList<ParentContact> cList = new ArrayList<ParentContact>(); //전체 목록
    private ArrayList<ParentContact> filteredList = new ArrayList <ParentContact>(); //검색될 때 필터링 된 목록

    Filter listFilter;

    //Constructor
    public ContactsAdapter(){

    }

    @Override
    public int getCount() {
        return filteredList.size();
    }

    @Override
    public Object getItem(int position) {
        return filteredList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();

        if(convertView == null){
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.contact_item,parent,false);
        }

        //위젯 Layout 참조
        ImageView iconImageView = (ImageView)convertView.findViewById(R.id.person);
        TextView titleTextView = (TextView)convertView.findViewById(R.id.textView1);
        TextView descTextView = (TextView)convertView.findViewById(R.id.textView2);

        ParentContact contact = filteredList.get(position);

        iconImageView.setImageDrawable(contact.getIcon());
        titleTextView.setText(contact.getTitle());
        descTextView.setText(contact.getDesc());

        return convertView;
    }

    @Override
    public Filter getFilter() {
        if(listFilter==null){
            listFilter = new ListFilter();
        }
        return listFilter;
    }

    public void addItem(Drawable icon, String title, String desc){
        ParentContact contact = new ParentContact();

        contact.setIcon(icon);
        contact.setTitle(title);
        contact.setDesc(desc);

        cList.add(contact);
    }

    private class ListFilter extends Filter{

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();

            if(constraint == null || constraint.length() == 0){ //아무것도 검색 X
                results.values = cList;
                results.count = cList.size();
            }else{
                ArrayList<ParentContact> itemList = new ArrayList<ParentContact>();

                for(ParentContact item : cList){
                    if(item.getTitle().toUpperCase().contains(constraint.toString().toUpperCase()) ||
                            item.getDesc().toUpperCase().contains(constraint.toString().toUpperCase())){
                        itemList.add(item);
                    }
                }
                results.values = itemList;
                results.count = itemList.size();

            }
            return  results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {

            filteredList = (ArrayList<ParentContact>)results.values;

            if(results.count>0){
                notifyDataSetChanged();
            }else{
                notifyDataSetInvalidated();
            }

        }
    }

}
