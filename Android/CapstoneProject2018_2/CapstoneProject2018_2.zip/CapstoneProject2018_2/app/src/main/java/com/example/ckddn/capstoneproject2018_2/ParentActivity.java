package com.example.ckddn.capstoneproject2018_2;

import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class ParentActivity extends AppCompatActivity {

    ListView cListView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent);

        ContactsAdapter contactsAdapter;
        contactsAdapter = new ContactsAdapter();

        Button editParentInfoBtn = (Button)findViewById(R.id.p_edit);
        editParentInfoBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ParentActivity.this, EditParentInfo.class);
                startActivity(intent);
            }
        });




        cListView = (ListView)findViewById(R.id.clistview);
        cListView.setAdapter(contactsAdapter);
        contactsAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.parent_icon), "정태연", "캐나다 백수");
        contactsAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.parent_icon), "양동욱", "메가박스 알바생");


        EditText editTextFilter = (EditText)findViewById(R.id.editTextFilter);
        editTextFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                String filterText = s.toString();
                if(filterText.length()>0){
                    cListView.setFilterText(filterText);
                }else{
                    cListView.clearTextFilter();
                }


            }
        });


    }

}
