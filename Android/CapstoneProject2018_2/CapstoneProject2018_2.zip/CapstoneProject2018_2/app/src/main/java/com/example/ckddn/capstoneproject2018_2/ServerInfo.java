package com.example.ckddn.capstoneproject2018_2;


public interface ServerInfo {
    /*  setting server ip address   */
    public static final String ipAddress = "35.221.104.89:5555";   //  Google Cloud Platform 외부 고정 ip
//    public static final String ipAddress = "192.168.219.105:5555";   //  Google Cloud Platform 외부 고정 ip

}
