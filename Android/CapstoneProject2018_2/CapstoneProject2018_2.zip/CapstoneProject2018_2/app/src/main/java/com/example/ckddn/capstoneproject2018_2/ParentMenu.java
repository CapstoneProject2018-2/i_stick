package com.example.ckddn.capstoneproject2018_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

//보호자가 관리 대상을 선정하면 나오는 메뉴

public class ParentMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_menu);
    }
}
