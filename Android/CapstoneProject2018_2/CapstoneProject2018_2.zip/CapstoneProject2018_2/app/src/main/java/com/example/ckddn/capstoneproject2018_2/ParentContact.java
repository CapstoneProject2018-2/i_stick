package com.example.ckddn.capstoneproject2018_2;

import android.graphics.drawable.Drawable;

//보호자 모드에서의 연락처 model class
public class ParentContact {
    private Drawable icon;
    private String title;
    private String desc;

    public void setIcon(Drawable icon){
        this.icon = icon;
    }

    public void setTitle(String title){
        this.title = title;
    }

    public void setDesc(String desc){
        this.desc = desc;
    }

    public Drawable getIcon(){
        return this.icon;
    }

    public String getTitle(){
        return this.title;
    }

    public String getDesc(){
        return this.desc;
    }


}


